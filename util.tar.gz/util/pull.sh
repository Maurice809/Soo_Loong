# **************************************************************************** #
#                                                                              #
#                                                         :::      ::::::::    #
#    pull.sh                                            :+:      :+:    :+:    #
#                                                     +:+ +:+         +:+      #
#    By: Maurice809 <maurice809@hotmail.com>        +#+  +:+       +#+         #
#                                                 +#+#+#+#+#+   +#+            #
#    Created: 2021/12/07 11:12:45 by Maurice809        #+#    #+#              #
#    Updated: 2022/04/29 17:56:07 by tmoret           ###   ########.fr        #
#                                                                              #
# **************************************************************************** #

#!/bin/bash

fichier=$(head -n 1 ./util/project.txt)

git config --global user.email "maurice809@hotmail.com"
git config --global user.name "Maurice809"

git pull  git@github.com:Maurice809/$fichier
